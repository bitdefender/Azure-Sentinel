const container = require("./dist/src/functions/lib/di-container").container;
const Application = require("./dist/src/functions/lib/application").Application;

const appInstance = container.resolve(Application);